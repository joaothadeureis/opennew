
import React from 'react';
import { CONTENT, BRAND } from '../constants';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-white border-t border-gray-100 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-center gap-8">
          
          <div className="flex items-center gap-2">
             <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center text-white font-bold text-xl">
              O
            </div>
            <span className="font-heading font-bold text-xl text-secondary tracking-tight">
              {BRAND.name}
            </span>
          </div>

          <div className="flex flex-wrap justify-center gap-8">
            {CONTENT.footer.links.map((link) => (
              <a 
                key={link} 
                href="#" 
                className="text-sm text-gray-500 hover:text-primary transition-colors"
              >
                {link}
              </a>
            ))}
          </div>

          <div className="text-sm text-gray-400 flex items-center gap-2 flex-col md:flex-row text-center">
            <span>{CONTENT.footer.copyright}</span>
            <span className="hidden md:inline">•</span>
            <span>
              Feito com ❤️ por <a href="https://agenciamaximum.com" style={{fontWeight: 600, textDecoration: 'underline'}} target="_blank" rel="noreferrer" className="hover:text-primary transition-colors">Agência Maximum</a>
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
};
