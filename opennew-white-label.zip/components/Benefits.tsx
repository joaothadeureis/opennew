
import React from 'react';
import { motion } from 'framer-motion';
import { Section } from './ui/Section';
import { CONTENT } from '../constants';

export const Benefits: React.FC = () => {
  // Split cards into left and right groups
  const leftCards = CONTENT.benefits.cards.slice(0, 3);
  const rightCards = CONTENT.benefits.cards.slice(3, 6);

  return (
    <Section>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-secondary mb-4 tracking-tight">
            {CONTENT.benefits.heading}
          </h2>
        </div>

        <div className="grid lg:grid-cols-3 gap-8 items-center">
            
          {/* Left Column */}
          <div className="space-y-6">
            {leftCards.map((card, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-lg transition-all duration-300"
              >
                <div className="mb-4 p-2.5 rounded-lg bg-surface text-secondary w-fit">
                  <card.icon size={24} className="stroke-primary" />
                </div>
                <h3 className="text-lg font-bold text-secondary mb-2">
                  {card.title}
                </h3>
                <p className="text-sm text-gray-600 leading-relaxed">
                  {card.text}
                </p>
              </motion.div>
            ))}
          </div>

          {/* Center Image */}
          <div className="hidden lg:block relative h-full min-h-[500px]">
             <div className="absolute inset-0 bg-primary/10 rounded-full blur-3xl transform scale-90" />
             <img 
                src={CONTENT.benefits.center_image} 
                alt="Support Team" 
                className="relative z-10 w-full h-full object-cover rounded-3xl shadow-2xl mask-image-b-fade"
                style={{ maxHeight: '600px' }}
             />
          </div>

          {/* Right Column */}
          <div className="space-y-6">
            {rightCards.map((card, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-lg transition-all duration-300"
              >
                <div className="mb-4 p-2.5 rounded-lg bg-surface text-secondary w-fit">
                  <card.icon size={24} className="stroke-primary" />
                </div>
                <h3 className="text-lg font-bold text-secondary mb-2">
                  {card.title}
                </h3>
                <p className="text-sm text-gray-600 leading-relaxed">
                  {card.text}
                </p>
              </motion.div>
            ))}
          </div>

        </div>
      </div>
    </Section>
  );
};