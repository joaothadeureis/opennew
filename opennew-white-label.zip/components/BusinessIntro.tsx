
import React from 'react';
import { motion } from 'framer-motion';
import { Section } from './ui/Section';
import { CONTENT } from '../constants';

export const BusinessIntro: React.FC = () => {
  return (
    <Section className="relative overflow-hidden">
      {/* Background Gradients */}
      <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-l from-surface to-transparent z-0" />
      <div className="absolute bottom-0 left-0 w-1/3 h-1/2 bg-gradient-to-t from-surface to-transparent z-0" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="order-2 lg:order-1 relative"
          >
             <div className="absolute -top-10 -left-10 w-24 h-24 bg-primary/20 rounded-full blur-2xl opacity-50" />
             <div className="absolute -bottom-10 -right-10 w-32 h-32 bg-accent/20 rounded-full blur-2xl opacity-50" />
             <img 
                src={CONTENT.business_intro.image} 
                alt="Business Growth" 
                className="relative rounded-2xl shadow-2xl w-full object-cover h-[400px] lg:h-[500px]"
              />
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="order-1 lg:order-2 space-y-6"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-secondary tracking-tight">
              {CONTENT.business_intro.heading}
            </h2>
            <p className="text-lg text-gray-600 leading-relaxed">
              {CONTENT.business_intro.text}
            </p>
            <div className="pt-4">
                <div className="h-1.5 w-24 bg-primary rounded-full" />
            </div>
          </motion.div>

        </div>
      </div>
    </Section>
  );
};