
import React from 'react';
import { motion } from 'framer-motion';
import { Button } from './ui/Button';
import { Section } from './ui/Section';
import { CONTENT } from '../constants';
import { ChevronRight } from 'lucide-react';

export const Hero: React.FC = () => {
  return (
    <Section className="pt-32 pb-20 md:pt-48 md:pb-32 bg-gradient-to-br from-white via-surface to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="space-y-8"
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 border border-primary/20 text-secondary text-xs font-semibold tracking-wide uppercase">
              <span className="w-2 h-2 rounded-full bg-primary animate-pulse"/>
              White Label Solution
            </div>
            
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-heading font-bold text-secondary leading-[1.1] tracking-tight">
              {CONTENT.hero.heading}
            </h1>
            
            <p className="text-lg text-gray-600 leading-relaxed max-w-lg">
              {CONTENT.hero.subheading}
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <Button href={CONTENT.hero.cta_primary.link} className="group">
                {CONTENT.hero.cta_primary.text}
                <ChevronRight className="ml-2 w-4 h-4 transition-transform group-hover:translate-x-1" />
              </Button>
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative"
          >
            <div className="absolute -inset-4 bg-gradient-to-r from-primary/30 to-accent/30 rounded-[2rem] blur-2xl opacity-40" />
            <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-gray-100 bg-white">
              <img 
                src={CONTENT.hero.image} 
                alt="OpenNew Dashboard" 
                className="w-full h-auto object-cover transform hover:scale-105 transition-transform duration-700"
              />
            </div>
          </motion.div>
          
        </div>
      </div>
    </Section>
  );
};