import React from 'react';
import { Section } from './ui/Section';
import { CONTENT } from '../constants';

export const Integrations: React.FC = () => {
  return (
    <Section background="gray" className="!py-16" id="integrações">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h3 className="text-lg font-semibold text-gray-500 uppercase tracking-widest mb-10">
          {CONTENT.integrations.heading}
        </h3>
        
        <div className="flex flex-wrap justify-center items-center gap-x-12 gap-y-8 opacity-60">
          {CONTENT.integrations.logos.map((logo, idx) => (
            <span 
              key={idx} 
              className="text-xl md:text-2xl font-bold text-gray-400 font-heading hover:text-secondary transition-colors cursor-default"
            >
              {logo}
            </span>
          ))}
        </div>
      </div>
    </Section>
  );
};